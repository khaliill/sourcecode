﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebApplication1.Data;
using WebApplication1.Models;

namespace WebApplication1.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class demandesController : ControllerBase
    {
        private readonly WebApplication1Context _context;

        public demandesController(WebApplication1Context context)
        {
            _context = context;
        }

        // GET: api/demandes
        [HttpGet]
        public async Task<ActionResult<IEnumerable<demandes>>> Getdemandes()
        {
            return await _context.demandes.ToListAsync();
        }

        // GET: api/demandes/5
        [HttpGet("{id}")]
        public async Task<ActionResult<demandes>> Getdemandes(int id)
        {
            var demandes = await _context.demandes.FindAsync(id);

            if (demandes == null)
            {
                return NotFound();
            }

            return demandes;
        }

        // PUT: api/demandes/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        public async Task<IActionResult> Putdemandes(int id, demandes demandes)
        {
            if (id != demandes.Id)
            {
                return BadRequest();
            }

            _context.Entry(demandes).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!demandesExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/demandes
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<demandes>> Postdemandes(demandes demandes)
        {
            _context.demandes.Add(demandes);
            await _context.SaveChangesAsync();

            return CreatedAtAction("Getdemandes", new { id = demandes.Id }, demandes);
        }

        // DELETE: api/demandes/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> Deletedemandes(int id)
        {
            var demandes = await _context.demandes.FindAsync(id);
            if (demandes == null)
            {
                return NotFound();
            }

            _context.demandes.Remove(demandes);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool demandesExists(int id)
        {
            return _context.demandes.Any(e => e.Id == id);
        }
    }
}
