﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace WebApplication1.Models
{
    public class demandes
    {
		[Key]
		public int Id { get; set; }
		public string Nom { get; set; }
		public string Prenom { get; set; }
		public string Motif { get; set; }
		public string vehicule { get; set; }
		public string matricule { get; set; }
		public int ContactNumber { get; set; }
	}
}
