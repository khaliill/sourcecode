const variables={
    API_URL:"https://localhost:44354/api/",
    
}