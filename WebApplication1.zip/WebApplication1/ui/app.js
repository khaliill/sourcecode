/* const routes=[
    {path:'/home',component:home},
    {path:'/demandes',component:demandes},
  

] */



// 2. Define some routes
// Each route should map to a component.
// We'll talk about nested routes later.
const routes = [
  { path: '/home', component: home },
  {path:'/demandes',component:demandes},
]
const router = VueRouter.createRouter({
    // 4. Provide the history implementation to use. We are using the hash history for simplicity here.
    history: VueRouter.createWebHashHistory(),
    routes : [{ path: '/demandes', component: demandes},
    { path: '/home', component: home },
  ], // short for `routes: routes`
  })
  const app = Vue.createApp({})
// Make sure to _use_ the router instance to make the
// whole app router-aware.
   app.use(router)

app.mount('#app')